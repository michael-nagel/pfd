# !/usr/bin/env python3
# -*- coding: utf-8 -*-

# Imports

from typing import Dict, List

import numpy as np
import pandas as pd
from scipy.stats import chi2

from pfd.utils import _create_gmm_data, _GenMethMom

# Function


def fit_gmm_mod(
    df: pd.DataFrame,
    n_per: int,
    incr: int,
    start_params: np.ndarray,
    max_iter: int | str,
    bookie: str,
) -> List[Dict[str, float]]:
    """
    Fit GMM model.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame.
    n_per : int
        Number of periods.
    incr : int
        Incremental step for periods.
    start_params : np.ndarray
        Starting values for the parameters to be estimated.
    max_iter : int | str
        Maximum number of iterations.
    bookie : str
        Bookmaker.

    Returns
    -------
    List[Dict[str, float]]
        List of Dictionaries containing various metrics.
    """
    endog, exog, inst = _create_gmm_data(
        df=df.loc[df["Bookies"] == bookie, :], n_per=n_per, incr=incr
    )

    mod_gmm = _GenMethMom(
        endog=endog,
        exog=exog,
        instrument=inst,
        k_moms=14,
        k_params=1,
        n_per=n_per,
    )

    res_tot: List[Dict[str, float]] = []

    for start_params_vals in start_params:
        if max_iter == 1:
            res_gmm = mod_gmm.fit(
                start_params=start_params_vals,
                maxiter=max_iter,
                optim_method="nm",
                has_optimal_weights=False,
                inv_weights=np.eye(N=14),
            )

            moment_mean = moment_conditions.mean(axis=0)
            # Calculate (average) gradient (Jacobian) of moments w.r.t parameters (G)
            G = mod_gmm.gradient_momcond(res_gmm.params).mean(axis=0)

            # Get Moment Conditions
            moment_conditions = mod_gmm.momcond(res_gmm.params)
            # Variance-Covariance Matrix (Omega)
            moment_avar = (
                moment_conditions.T @ moment_conditions
            ) / endog.shape[0]

            # Weighting Matrix
            W = np.eye(14)

            # Calculate Sandwich Covariance: (G'WG)^-1 G' W Omega W G (G'WG)^-1
            # Since W is identity, this simplifies to: (G'G)^-1 G' Omega G (G'G)^-1
            gwg_inv = np.linalg.inv(G.T @ W @ G)

            # Variance of params
            var_params = gwg_inv @ (G.T @ W @ moment_avar @ W @ G) @ gwg_inv

            # Standard Error (divide by n for asymptotic variance scaling
            # to get sample variance)
            bse = np.sqrt(np.diag(var_params) / endog.shape[0])

            j_stat = (
                endog.shape[0]
                * moment_mean.T
                @ np.linalg.pinv(moment_avar)
                @ moment_mean
            )
            # Degrees of freedom: #moment conditions - #parameters
            degr = 14 - 1
            # Chi-squared test
            p_value = 1 - chi2.cdf(j_stat, degr)

            res_tot.append(
                {
                    "gamma": res_gmm.params[0],
                    "std_gamma": bse[0],
                    "J_stat": j_stat,
                    "p_value": p_value,
                }
            )
        # if max_iter == 1:
        #     res_gmm = mod_gmm.fit(
        #         start_params=start_params_vals,
        #         maxiter=max_iter,
        #         optim_method="nm",
        #         has_optimal_weights=False,
        #         inv_weights=np.eye(N=14),
        #     )  # "nm", "bfgs"
        #     moment_conditions = mod_gmm.momcond(res_gmm.params)
        #     moment_mean = moment_conditions.mean(axis=0)
        #     moment_avar = (
        #         moment_conditions.T @ moment_conditions / endog.shape[0]
        #     )
        #     j_stat = (
        #         endog.shape[0]
        #         * moment_mean.T
        #         @ np.linalg.pinv(moment_avar)
        #         @ moment_mean
        #     )
        #     # Degrees of freedom: #moment conditions - #parameters
        #     degr = 14 - 1
        #     # Chi-squared test
        #     p_value = 1 - chi2.cdf(j_stat, degr)

        #     res_tot.append(
        #         {
        #             "gamma": res_gmm.params[0],
        #             "std_gamma": res_gmm.bse[0],
        #             "J_stat": j_stat,
        #             "p_value": p_value,
        #         }
        #     )
        else:
            res_gmm = mod_gmm.fit(
                start_params=start_params_vals,
                maxiter=max_iter,
                optim_method="nm",
            )  # "nm", "bfgs"
            res_tot.append(
                {
                    "gamma": res_gmm.params[0],
                    "std_gamma": res_gmm.bse[0],
                    "J_stat": res_gmm.jtest()[0],
                    "p_value": res_gmm.jtest()[1],
                }
            )

    return res_tot
